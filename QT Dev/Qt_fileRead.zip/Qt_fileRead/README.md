# QT Application to read from a file every 1 second

## Installation:

```sh
sudo apt install libqt5charts5-dev
```

## Compilation:

```
qmake Temperature.pro

make
```